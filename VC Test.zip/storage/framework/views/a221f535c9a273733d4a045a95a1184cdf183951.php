<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Livewire Crud Example</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <?php echo \Livewire\Livewire::styles(); ?>

</head>
<body>
    <div class="container">
        <div class="row justify-content-center mt-3">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('home')->html();
} elseif ($_instance->childHasBeenRendered('dS09yZM')) {
    $componentId = $_instance->getRenderedChildComponentId('dS09yZM');
    $componentTag = $_instance->getRenderedChildComponentTagName('dS09yZM');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('dS09yZM');
} else {
    $response = \Livewire\Livewire::mount('home');
    $html = $response->html();
    $_instance->logRenderedChild('dS09yZM', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
    <?php echo \Livewire\Livewire::scripts(); ?>

</body>
</html>
<?php $__env->stopSection(); ?>
<script>
    document.addEventListener("DOMContentLoaded", function(){
        let root = document.querySelector('[drag-root]');
        
        root.querySelectorAll('[drag-item]').forEach(el => {

            el.addEventListener('dragstart', e => {
                e.target.setAttribute('dragging',true)
            })

            el.addEventListener('drop', e => {
                e.target.classList.remove('bg-yellow-100')
                
                let draggingEl = root.querySelector('[dragging]')
                e.target.before(draggingEl)

                //Refresh the livewire component
                let component = Livewire.find(
                    e.target.closest('[wire\\:id]').getAttribute('wire:id')
                )
                //component.call('$refresh')
            })

            el.addEventListener('dragenter', e => {
                e.target.classList.add('bg-yellow-100')
                e.preventDefault()
            })

            el.addEventListener('dragover', e => e.preventDefault())

            el.addEventListener('dragleave', e => {
                e.target.classList.remove('bg-yellow-100')
            })

            el.addEventListener('dragend', e => {
                e.target.removeAttribute('dragging')
            })
        })
    })
</script>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/laravel-test/resources/views/home.blade.php ENDPATH**/ ?>