<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Livewire Crud Example</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <?php echo \Livewire\Livewire::styles(); ?>

</head>
<body>
    <div class="container">
        <div class="row justify-content-center mt-3">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('category')->html();
} elseif ($_instance->childHasBeenRendered('35rcpsY')) {
    $componentId = $_instance->getRenderedChildComponentId('35rcpsY');
    $componentTag = $_instance->getRenderedChildComponentTagName('35rcpsY');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('35rcpsY');
} else {
    $response = \Livewire\Livewire::mount('category');
    $html = $response->html();
    $_instance->logRenderedChild('35rcpsY', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
    
    <?php echo \Livewire\Livewire::scripts(); ?>

</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/laravel-test/resources/views/category.blade.php ENDPATH**/ ?>