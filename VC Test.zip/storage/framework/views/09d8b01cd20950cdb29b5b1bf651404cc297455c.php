<div>
    <table class="table">
        <thead>
            <tr>
                <th>Catgeory & Item List</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>
                    <div class="col-md-6 treesdrg">
                        <ul id="tree1">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="droppable">
                                    <?php echo e($category->name); ?>

                                    <?php if(count($category->children)): ?>
                                        <?php echo $__env->make('../manageChild',['children' => $category->children], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php endif; ?>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
</div><?php /**PATH /var/www/html/laravel-test-live/resources/views/livewire/home.blade.php ENDPATH**/ ?>