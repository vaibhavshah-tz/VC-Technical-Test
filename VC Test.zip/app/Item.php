<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Item extends Model
{
    protected $table = 'categories';
    protected $fillable = [
        'name','catid','item'
    ];

    public function children()
    {
        return $this->hasMany('categories', 'catid', 'id');
    }
    public function parent()
    {
        return $this->belongsTo('categories', 'catid');
    }
}