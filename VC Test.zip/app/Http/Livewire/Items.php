<?php

namespace App\Http\Livewire;
use App\Category as Categories;
use Livewire\Component;

class Items extends Component
{
    public $categories, $name, $category_id, $category,$getData,$cid;
    public $updateItem = false;

    protected $listeners = [
        'deleteItem'=>'destroy'
    ];

    protected $rules = [
        'name'=>'required',
        //'category'=>'required'
    ];

    public function render()
    {
        $this->categories = Categories::select('id','name')->where('item',1)->get();
        return view('livewire.items');
    }
    public function mount()
    {
        $this->getData = Categories::select('id','name')->whereNull('item')->get();
    }
    public function resetFields(){
        $this->name = '';
        $this->category = '';
    }
    public function store()
    {
        $this->validate();
        
        try{
            Categories::create([
                'name'=>$this->name,
                'catid'=>$this->category,
                'item'=>1         
            ]);           
    
            session()->flash('success','Item Created Successfully!!');
            $this->resetFields();
        }
        catch(\Exception $e)
        {
            session()->flash('error','Something goes wrong while creating item!!');
            $this->resetFields();
        }
    }
    public function edit($id){
        $category = Categories::findOrFail($id);
        $this->name = $category->name;
        $this->cid = $category->catid;
        $this->category_id = $category->id;
        $this->updateItem = true;
    }
    public function cancel()
    {
        $this->updateItem = false;
        $this->resetFields();
    }
    public function update()
    {
        $this->validate();

        try{
            Categories::find($this->category_id)->fill([
                'name'=>$this->name,
                'catid'=>$this->cid,
                'item'=>1            
            ])->save();
           
            session()->flash('success','Item Updated Successfully!!');
            $this->cancel();

        }catch(\Exception $e){
            session()->flash('error','Something goes wrong while updating item!!');
            $this->cancel();
        }
    }
    public function destroy($id){
        try{
            Categories::find($id)->delete();
            session()->flash('success',"Item Deleted Successfully!!");
        }catch(\Exception $e){
            session()->flash('error',"Something goes wrong while deleting item!!");
        }
    }
}