<?php

namespace App\Http\Livewire;
use App\Category as Categories;
use Livewire\Component;

class Home extends Component
{
    public $categories;

    public function render()
    {
        $this->categories = Categories::with('children')->whereNull('catid')->get();

        return view('livewire.home');
    }
}
