<?php

namespace App\Http\Livewire;
use App\Category as Categories;
use Livewire\Component;

class Category extends Component
{
    public $categories, $name, $category_id, $category,$getData;
    public $updateCategory = false;

    protected $listeners = [
        'deleteCategory'=>'destroy'
    ];

    // Validation Rules
    protected $rules = [
        'name'=>'required'
    ];

    public function render()
    {
        $this->categories = Categories::select('id','name')->whereNull('item')->get();
        return view('livewire.category');
    }
    public function mount()
    {
        $this->getData = Categories::select('id','name')->whereNull('item')->get();
    }
    public function resetFields(){
        $this->name = '';
        $this->category = '';
    }
    public function store()
    {
        //$this->validate();
        try{
            if(empty($this->category)){
                $data = Categories::create([
                    'name'=>$this->name           
                ]);
            }
            else{
                Categories::create([
                    'name'=>$this->name,
                    'catid'=>$this->category          
                ]);
            }            
    
            session()->flash('success','Category Created Successfully!!');
            $this->resetFields();
        }
        catch(\Exception $e)
        {
            // print_r($e);
            // exit;
            session()->flash('error','Something goes wrong while creating category!!');
            $this->resetFields();
        }
    }
    public function edit($id){
        $category = Categories::findOrFail($id);
        $this->name = $category->name;
        $this->catid = $category->catid;
        $this->category_id = $category->id;
        $this->updateCategory = true;
    }
    public function cancel()
    {
        $this->updateCategory = false;
        $this->resetFields();
    }
    public function update()
    {
        $this->validate();

        try{
            if(empty($this->category))
            {
                Categories::find($this->category_id)->fill([
                    'name'=>$this->name            
                ])->save();
            }
            else
            {
                Categories::find($this->category_id)->fill([
                    'name'=>$this->name,
                    'catid'=>$this->category            
                ])->save();
            }
            
            session()->flash('success','Category Updated Successfully!!');
    
            $this->cancel();
        }catch(\Exception $e){
            session()->flash('error','Something goes wrong while updating category!!');
            $this->cancel();
        }
    }
    public function destroy($id){
        try{
            Categories::find($id)->delete();
            session()->flash('success',"Category Deleted Successfully!!");
        }catch(\Exception $e){
            session()->flash('error',"Something goes wrong while deleting category!!");
        }
    }
}