<ul drag-root>
    @foreach($children as $child)
        <li drag-item draggable="true">
            {{ $child->name }}
            @if(count($child->children))
                @include('manageChild',['children' => $child->children])
            @endif
        </li>
    @endforeach
</ul>