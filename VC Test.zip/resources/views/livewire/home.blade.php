<div>
    <table class="table">
        <thead>
            <tr>
                <th>Catgeory & Item List</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>
                    <div class="col-md-6 treesdrg">
                        <ul id="tree1">
                            @foreach($categories as $category)
                                <li class="droppable">
                                    {{ $category->name }}
                                    @if(count($category->children))
                                        @include('../manageChild',['children' => $category->children])
                                    @endif
                                </li>
                            @endforeach
                        </ul>
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
</div>