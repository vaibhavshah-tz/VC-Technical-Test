<?php return array (
  'category' => 'App\\Http\\Livewire\\Category',
  'home' => 'App\\Http\\Livewire\\Home',
  'items' => 'App\\Http\\Livewire\\Items',
);